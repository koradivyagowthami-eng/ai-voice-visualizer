from django import forms
from .models import Feedback


class FeedbackForm(forms.ModelForm):

    password = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                'placeholder': 'Enter password',
                'class': 'form-control',
            }
        )
    )

    confirm_password = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                'placeholder': 'Confirm password',
                'class': 'form-control',
            }
        )
    )

    def clean_name(self):
        name = self.cleaned_data['name'].strip()

        if len(name) < 3:
            raise forms.ValidationError(
                "Name must contain at least 3 characters."
            )

        if not name[0].isupper():
            raise forms.ValidationError(
                "Name must start with an uppercase letter."
            )

        return name

    def clean(self):
        cleaned_data = super().clean()

        password = cleaned_data.get('password')
        confirm_password = cleaned_data.get('confirm_password')

        if password and confirm_password:
            if password != confirm_password:
                raise forms.ValidationError(
                    "Passwords do not match."
                )

        return cleaned_data

    class Meta:
        model = Feedback
        fields = ['name', 'email', 'phone', 'feedback']

        widgets = {
            'name': forms.TextInput(
                attrs={
                    'placeholder': 'Enter your full name',
                    'class': 'form-control',
                }
            ),
            'email': forms.EmailInput(
                attrs={
                    'placeholder': 'Enter your email address',
                    'class': 'form-control',
                }
            ),
            'phone': forms.NumberInput(
                attrs={
                    'placeholder': 'Enter your phone number',
                    'class': 'form-control',
                }
            ),
            'feedback': forms.Textarea(
                attrs={
                    'placeholder': 'Share your feedback with us',
                    'class': 'form-control',
                    'rows': 5,
                }
            ),
        }

        labels = {
            'name': 'Name',
            'email': 'Email',
            'phone': 'Phone Number',
            'feedback': 'Feedback',
        }