import { ArrowRight, BarChart3, Check, ClipboardList, Play, Shield, Sparkles, Users } from "lucide-react";

const amenities = [
  { label: "Live Inventory", icon: ClipboardList },
  { label: "Guest Leads", icon: Users },
  { label: "Secure Payouts", icon: Shield },
];

const stats = ["500+ Partners", "50+ Cities", "10K+ Bookings"];

export default function Hero() {
  return (
    <section id="home" className="relative min-h-[840px] overflow-hidden bg-[#081b2a] pt-[58px] lg:min-h-screen">
      <div className="absolute inset-y-[58px] right-0 w-full bg-[url('https://images.unsplash.com/photo-1618220179428-22790b461013?auto=format&fit=crop&w=1600&q=85')] bg-cover bg-center opacity-80 lg:w-1/2" aria-hidden="true" />
      <div className="absolute inset-0 bg-[linear-gradient(90deg,#082033_0%,#082033_42%,rgba(8,32,51,.8)_52%,rgba(8,32,51,.28)_100%)]" aria-hidden="true" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_18%_28%,rgba(23,198,244,.18),transparent_32%),radial-gradient(circle_at_85%_75%,rgba(13,194,243,.09),transparent_22%)]" aria-hidden="true" />

      <div className="relative mx-auto grid min-h-[calc(100vh-58px)] max-w-[1280px] items-center px-5 py-24 sm:px-8 lg:grid-cols-2 lg:px-10">
        <div className="max-w-[610px]">
          <h1 className="text-[48px] font-extrabold leading-[1.08] text-white sm:text-[66px] lg:text-[72px]">
            Grow Your<br />
            Hostel <span className="text-[#10c8f6]">Bookings</span>
          </h1>

          <div className="mt-8 flex items-center gap-3 text-slate-400">
            <span className="h-px w-14 bg-[#10c8f6]/50" />
            <span className="text-base font-medium">Partner Dashboard</span>
            <span className="relative text-[#10c8f6]">Built for Hostel Teams <Sparkles className="absolute -right-7 -top-2 h-4 w-4" /></span>
          </div>

          <p className="mt-8 max-w-[560px] text-lg leading-8 text-slate-400">
            Manage hostel listings, room inventory, pricing, guest inquiries, and booking requests from one clean platform made for hostel operations teams.
          </p>

          <div className="mt-8 flex flex-wrap gap-4">
            {amenities.map(({ label, icon: Icon }) => (
              <span key={label} className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-[#10283e]/70 px-4 py-2 text-sm font-bold text-white shadow-[inset_0_1px_0_rgba(255,255,255,.06)]">
                <span className="grid h-6 w-6 place-items-center rounded-full bg-[#10c8f6] text-white">
                  <Icon className="h-3.5 w-3.5" aria-hidden="true" />
                </span>
                {label}
              </span>
            ))}
          </div>

          <div className="mt-11 flex flex-wrap gap-4">
            <a href="#listings" className="inline-flex items-center gap-3 rounded-full bg-[#10c8f6] px-8 py-4 text-base font-extrabold text-[#062032] shadow-[0_18px_35px_rgba(16,200,246,.25)] transition hover:-translate-y-1 hover:bg-[#42d9ff]">
              <BarChart3 className="h-4 w-4" aria-hidden="true" />
              Manage Listings
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </a>
            <button className="inline-flex items-center gap-3 rounded-full border border-slate-500/80 bg-transparent px-8 py-4 text-base font-extrabold text-white transition hover:-translate-y-1 hover:border-[#10c8f6] hover:bg-white/5" type="button">
              <Play className="h-4 w-4" aria-hidden="true" />
              Watch Team Demo
            </button>
          </div>

          <div className="mt-12 flex max-w-[520px] flex-wrap gap-7 border-t border-white/10 pt-8 text-sm text-slate-400">
            {stats.map((item) => {
              const [value, label] = item.split(" ");
              return (
                <span key={item} className="inline-flex items-center gap-2">
                  <Check className="h-4 w-4 text-[#10c8f6]" aria-hidden="true" />
                  <strong className="mono-num text-white">{value}</strong> {label}
                </span>
              );
            })}
          </div>
        </div>
      </div>

      <div className="absolute bottom-3 left-1/2 -translate-x-1/2 text-xs font-semibold text-slate-400">Scroll to explore</div>
      <span className="absolute right-[8%] top-[34%] h-12 w-12 rotate-45 border border-[#10c8f6]/10" aria-hidden="true" />
      <span className="absolute bottom-[10%] right-[7%] h-16 w-16 rounded-full border border-[#10c8f6]/20" aria-hidden="true" />
    </section>
  );
}
