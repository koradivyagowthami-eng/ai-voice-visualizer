import { TrendingUp } from "lucide-react";

const mini = [
  {
    title: "Hostel Team Dashboard",
    copy: "Add and manage properties, room types, rates, policies, and inventory from one clean team workspace.",
  },
  {
    title: "Partner Operations",
    copy: "Coordinate front desk, sales, and operations work with clear booking status and availability controls.",
  },
];

const bars = [22, 36, 24, 44, 30, 50, 39, 52, 42, 55];
const tallBars = [20, 34, 24, 42, 29, 47, 37, 51, 39, 54];

function Chart({ values = bars }) {
  return (
    <div className="flex h-16 items-end gap-1.5" aria-hidden="true">
      {values.map((height, index) => (
        <span key={index} className="flex-1 rounded-t bg-gradient-to-t from-[#48d8ff]/70 to-[#0b93bd]" style={{ height: `${height}px` }} />
      ))}
    </div>
  );
}

export default function Features() {
  return (
    <section id="features" className="relative overflow-hidden bg-[#081827] px-5 py-12 sm:px-8 lg:px-10">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_15%_0%,rgba(22,196,244,.11),transparent_35%),radial-gradient(circle_at_80%_65%,rgba(22,196,244,.08),transparent_32%)]" aria-hidden="true" />
      <div className="relative mx-auto grid max-w-[1280px] gap-6 lg:grid-cols-[1fr_.95fr]">
        <article className="relative overflow-hidden rounded-2xl border border-white/8 bg-[#0c1f33] p-8 shadow-[0_22px_65px_rgba(0,0,0,.28)] sm:p-10">
          <h2 className="text-3xl font-extrabold text-white">Verified Hostel Profiles</h2>
          <p className="mt-3 max-w-2xl text-lg leading-8 text-slate-400">Keep photos, room details, policies, prices, and team-managed availability accurate across every hostel listing.</p>
          <div className="mt-28 border-t border-white/8 pt-8">
            <div className="flex items-end justify-between gap-4">
              <div>
                <p className="text-sm text-slate-400">Partner Hostels</p>
                <p className="mono-num mt-1 text-3xl font-extrabold text-white">1,200+</p>
              </div>
              <span className="rounded-full bg-[#0d314d] px-3 py-1 text-sm font-bold text-[#10c8f6]">+14%</span>
            </div>
            <div className="mt-7">
              <Chart />
            </div>
          </div>
          <span className="absolute -bottom-8 -right-6 h-28 w-28 rounded-full bg-[#10c8f6]/8" aria-hidden="true" />
        </article>

        <div className="grid gap-6">
          <div className="grid gap-6 md:grid-cols-2">
            {mini.map(({ title, copy }) => (
              <article key={title} className="relative overflow-hidden rounded-2xl border border-white/8 bg-[#0c1f33] p-8 shadow-[0_20px_55px_rgba(0,0,0,.22)]">
                <h3 className="text-2xl font-extrabold text-white">{title}</h3>
                <p className="mt-3 text-lg leading-7 text-slate-400">{copy}</p>
                <span className="absolute -bottom-8 -right-6 h-24 w-24 rounded-full bg-[#10c8f6]/8" aria-hidden="true" />
              </article>
            ))}
          </div>

          <article className="relative overflow-hidden rounded-2xl border border-white/8 bg-[#0c1f33] p-8 shadow-[0_20px_55px_rgba(0,0,0,.22)]">
            <h3 className="text-2xl font-extrabold text-white">Smart Booking Management</h3>
            <p className="mt-3 max-w-3xl text-lg leading-7 text-slate-400">Manage reservations, availability, check-ins, cancellations, and payouts from one hostel team dashboard.</p>
            <div className="mt-8 border-t border-white/8 pt-7">
              <div className="flex items-end justify-between gap-4">
                <div>
                  <p className="text-sm text-slate-400">Daily Booking Requests</p>
                  <p className="mono-num mt-1 text-3xl font-extrabold text-white">3.5K+</p>
                </div>
                <span className="inline-flex items-center gap-1 rounded-full bg-[#0d314d] px-3 py-1 text-sm font-bold text-[#10c8f6]"><TrendingUp className="h-4 w-4" /> +9%</span>
              </div>
              <div className="mt-7">
                <Chart values={tallBars} />
              </div>
            </div>
            <span className="absolute -bottom-8 -right-6 h-28 w-28 rounded-full bg-[#10c8f6]/8" aria-hidden="true" />
          </article>
        </div>
      </div>
    </section>
  );
}
