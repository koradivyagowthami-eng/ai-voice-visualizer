export function SectionShell({ id, children, className = "" }) {
  return (
    <section id={id} className={`relative overflow-hidden bg-[#081827] px-5 py-20 sm:px-8 lg:px-10 ${className}`}>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_15%,rgba(13,194,243,.08),transparent_28%)]" aria-hidden="true" />
      <div className="relative mx-auto max-w-[1280px]">{children}</div>
    </section>
  );
}

export function Badge({ children }) {
  return (
    <span className="mx-auto inline-flex items-center gap-2 rounded-full bg-[#0d314d] px-4 py-2 text-sm font-bold text-[#10c8f6] shadow-[inset_0_1px_0_rgba(255,255,255,.06)]">
      {children}
    </span>
  );
}

export function SectionHeading({ badge, title, accent, subtitle }) {
  return (
    <div className="mx-auto max-w-3xl text-center">
      {badge}
      <h2 className="mt-5 text-[38px] font-extrabold leading-tight text-white sm:text-[52px]">
        {title} {accent && <span className="text-[#10c8f6]">{accent}</span>}
      </h2>
      {subtitle && <p className="mx-auto mt-4 max-w-2xl text-lg leading-8 text-slate-400">{subtitle}</p>}
    </div>
  );
}
