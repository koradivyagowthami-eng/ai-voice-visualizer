import HomePage from "./pages/HomePage";
import HotelDetails from "./pages/HotelDetails";

function App() {
  const [, section, slug] = window.location.pathname.split("/");
  const isHotelPage = section === "hotels" && slug;

  return (
    <div className="min-h-screen overflow-x-hidden bg-[#081827] text-white">
      {isHotelPage ? <HotelDetails slug={slug} /> : <HomePage />}
    </div>
  );
}

export default App;
