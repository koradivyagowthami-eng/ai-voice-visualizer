import { Badge, SectionHeading, SectionShell } from "./SectionShell";
import { Award, Building2, MapPin, TrendingUp, Users, Zap } from "lucide-react";

const cards = [
  { icon: Building2, value: "1,200+", label: "Partner Hostels", copy: "Verified properties managed" },
  { icon: Users, value: "50,000+", label: "Guest Requests", copy: "Leads routed to hostel teams" },
  { icon: MapPin, value: "150+", label: "Service Areas", copy: "Cities and tourist hubs" },
  { icon: Award, value: "97%", label: "Team Response Rate", copy: "Fast replies from hostel partners" },
];

const marquee = ["Room Inventory", "Secure Payouts", "Rate Updates", "Booking Desk", "Guest Leads", "Quality Checks", "Team Dashboard", "Property Analytics"];

export default function Stats() {
  return (
    <SectionShell className="border-t border-[#10c8f6]/20 bg-[radial-gradient(circle_at_center,rgba(23,198,244,.09),transparent_35%)]">
      <div className="absolute inset-0 bg-[radial-gradient(rgba(255,255,255,.08)_1px,transparent_1px)] [background-size:28px_28px] opacity-20" aria-hidden="true" />
      <SectionHeading
        badge={<Badge><TrendingUp className="h-4 w-4" /> Growing Every Day</Badge>}
        title="Trusted by Hostel Teams Everywhere"
        subtitle="Give your front desk, sales, and operations teams one place to manage listings, bookings, pricing, and guest communication"
      />

      <div className="mt-16 grid gap-7 md:grid-cols-2 xl:grid-cols-4">
        {cards.map(({ icon: Icon, value, label, copy }) => (
          <article key={label} className="group relative overflow-hidden rounded-2xl border border-white/7 bg-[#0c1f33] p-8 text-left shadow-[0_22px_60px_rgba(0,0,0,.25)] transition duration-300 hover:-translate-y-2 hover:border-[#10c8f6]/35">
            <div className="grid h-14 w-14 place-items-center rounded-xl bg-[#10c8f6] shadow-[0_12px_28px_rgba(16,200,246,.28)]">
              <Icon className="h-7 w-7 text-white" aria-hidden="true" />
            </div>
            <p className="mono-num mt-7 text-[40px] font-extrabold leading-none text-white">{value}</p>
            <h3 className="mt-4 text-lg font-extrabold text-white">{label}</h3>
            <p className="mt-2 text-sm font-medium text-slate-400">{copy}</p>
            <span className="absolute -bottom-8 -right-7 h-24 w-24 rounded-full bg-[#10c8f6]/8 transition group-hover:bg-[#10c8f6]/15" aria-hidden="true" />
          </article>
        ))}
      </div>

      <div className="mt-16 flex gap-8 overflow-hidden text-slate-400">
        <div className="flex min-w-max animate-[slide_28s_linear_infinite] gap-8">
          {marquee.map((item, index) => (
            <span key={`${item}-${index}`} className="inline-flex items-center gap-2 text-sm font-semibold">
              <Zap className="h-4 w-4 text-[#10c8f6]" aria-hidden="true" />
              {item}
            </span>
          ))}
        </div>
      </div>
    </SectionShell>
  );
}
