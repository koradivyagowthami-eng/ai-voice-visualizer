import { useState } from "react";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import { v4 as uuid } from "uuid";

export default function Builder() {
  const [sections, setSections] = useState([
    {
      id: uuid(),
      type: "hero",
      title: "Build Websites Without Coding",
      description: "Drag, Drop, Edit and Publish.",
    },
  ]);

  const addSection = (type) => {
    const newSection = {
      id: uuid(),
      type,
      title: `${type} Section`,
      description: `Editable ${type} content`,
    };

    setSections([...sections, newSection]);
  };

  const deleteSection = (id) => {
    setSections(sections.filter((section) => section.id !== id));
  };

  const duplicateSection = (section) => {
    const copy = {
      ...section,
      id: uuid(),
    };

    setSections([...sections, copy]);
  };

  const updateSection = (id, field, value) => {
    setSections(
      sections.map((section) =>
        section.id === id
          ? { ...section, [field]: value }
          : section
      )
    );
  };

  const handleDragEnd = (result) => {
    if (!result.destination) return;

    const items = [...sections];
    const [reordered] = items.splice(result.source.index, 1);

    items.splice(result.destination.index, 0, reordered);

    setSections(items);
  };

  return (
    <div className="builder">

      {/* Sidebar */}
      <div className="sidebar">
        <h2>Components</h2>

        <button onClick={() => addSection("hero")}>
          Add Hero
        </button>

        <button onClick={() => addSection("features")}>
          Add Features
        </button>

        <button onClick={() => addSection("pricing")}>
          Add Pricing
        </button>

        <button onClick={() => addSection("faq")}>
          Add FAQ
        </button>
      </div>

      {/* Canvas */}
      <div className="canvas">

        <DragDropContext onDragEnd={handleDragEnd}>
          <Droppable droppableId="builder">
            {(provided) => (
              <div
                ref={provided.innerRef}
                {...provided.droppableProps}
              >
                {sections.map((section, index) => (
                  <Draggable
                    key={section.id}
                    draggableId={section.id}
                    index={index}
                  >
                    {(provided) => (
                      <div
                        className="section-card"
                        ref={provided.innerRef}
                        {...provided.draggableProps}
                        {...provided.dragHandleProps}
                      >

                        <div className="section-toolbar">
                          <button
                            onClick={() =>
                              duplicateSection(section)
                            }
                          >
                            Duplicate
                          </button>

                          <button
                            onClick={() =>
                              deleteSection(section.id)
                            }
                          >
                            Delete
                          </button>
                        </div>

                        <h2
                          contentEditable
                          suppressContentEditableWarning
                          onBlur={(e) =>
                            updateSection(
                              section.id,
                              "title",
                              e.target.innerText
                            )
                          }
                        >
                          {section.title}
                        </h2>

                        <p
                          contentEditable
                          suppressContentEditableWarning
                          onBlur={(e) =>
                            updateSection(
                              section.id,
                              "description",
                              e.target.innerText
                            )
                          }
                        >
                          {section.description}
                        </p>

                      </div>
                    )}
                  </Draggable>
                ))}

                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>

      </div>
    </div>
  );
}