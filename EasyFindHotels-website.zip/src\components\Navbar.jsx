import { Home, Info, Menu, Phone } from "lucide-react";

const navItems = [
  { label: "Home", href: "/#home", icon: Home, active: true },
  { label: "About Us", href: "/#features", icon: Info },
  { label: "Contact Us", href: "/#contact", icon: Phone },
];

export default function Navbar() {
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-white/10 bg-[#0b1c2e]/95 shadow-[0_8px_35px_rgba(0,0,0,.22)] backdrop-blur-xl">
      <nav className="mx-auto flex h-[58px] max-w-[1280px] items-center justify-between px-5 sm:px-8 lg:px-10" aria-label="Primary navigation">
        <a href="/#home" className="script-logo text-[25px] font-bold leading-none text-white transition hover:scale-[1.02]">
          <span className="text-[#20c5f5]">EasyFind</span>Hotels
        </a>

        <div className="hidden items-center gap-3 md:flex">
          {navItems.map(({ label, href, icon: Icon, active }) => (
            <a
              key={label}
              href={href}
              className={`group flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold transition ${
                active
                  ? "bg-[#103451] text-[#14c8fb] shadow-[0_10px_24px_rgba(3,169,244,.16)]"
                  : "text-slate-400 hover:bg-white/5 hover:text-white"
              }`}
            >
              <Icon aria-hidden="true" className="h-4 w-4 transition group-hover:scale-110" />
              {label}
            </a>
          ))}
        </div>

        <a href="/#listings" className="hidden rounded-full bg-[#10c5f4] px-5 py-2.5 text-sm font-bold text-[#062032] shadow-[0_10px_30px_rgba(16,197,244,.35)] transition hover:-translate-y-0.5 hover:bg-[#38d7ff] sm:inline-flex">
          Get Started
        </a>

        <button className="rounded-xl border border-white/10 bg-white/5 p-2 text-slate-200 md:hidden" aria-label="Open menu">
          <Menu className="h-5 w-5" aria-hidden="true" />
        </button>
      </nav>
    </header>
  );
}
