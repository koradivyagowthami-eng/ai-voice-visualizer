from django import forms

from .models import Feedback


class FeedbackForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ['name', 'email', 'phone', 'feedback']
        widgets = {
            'name': forms.TextInput(
                attrs={
                    'placeholder': 'Enter your full name',
                    'class': 'form-control',
                }
            ),
            'email': forms.EmailInput(
                attrs={
                    'placeholder': 'Enter your email address',
                    'class': 'form-control',
                }
            ),
            'phone': forms.NumberInput(
                attrs={
                    'placeholder': 'Enter your phone number',
                    'class': 'form-control',
                }
            ),
            'feedback': forms.Textarea(
                attrs={
                    'placeholder': 'Share your feedback with us',
                    'class': 'form-control',
                    'rows': 5,
                }
            ),
        }
        labels = {
            'name': 'Name',
            'email': 'Email',
            'phone': 'Phone Number',
            'feedback': 'Feedback',
        }
