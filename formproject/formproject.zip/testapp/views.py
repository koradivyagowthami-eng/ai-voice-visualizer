from django.contrib import messages
from django.shortcuts import redirect, render

from .forms import FeedbackForm


def feedback_view(request):
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Thank you! Your feedback has been submitted successfully.')
            return redirect('success')
    else:
        form = FeedbackForm()

    return render(request, 'feedback.html', {'form': form})


def success_view(request):
    return render(request, 'success.html')
